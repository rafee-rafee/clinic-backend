-- phpMyAdmin SQL Dump
-- version 4.8.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 29, 2018 at 07:59 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `medical`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

CREATE TABLE `appointments` (
  `id` int(11) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `date_of_birth` date NOT NULL,
  `phone_number` varchar(255) NOT NULL,
  `email_address` varchar(255) NOT NULL,
  `mailing_address` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `province` varchar(255) NOT NULL,
  `postal_code` varchar(255) NOT NULL,
  `doctor_name` varchar(255) NOT NULL,
  `reason` varchar(255) NOT NULL,
  `appointment_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `appointments`
--

INSERT INTO `appointments` (`id`, `first_name`, `last_name`, `date_of_birth`, `phone_number`, `email_address`, `mailing_address`, `city`, `province`, `postal_code`, `doctor_name`, `reason`, `appointment_date`) VALUES
(2, 'MD. Mahmudul Hasan', 'Rafee', '1990-11-23', '+14039152450', 'mmhrafee@gmail.com', '10965 84 st NW', 'Edmonton', 'Alberta', 'T5H 1M5', 'Dr. AbduKadr', 'Regular Checkup', '2018-05-02'),
(3, 'Farhana', 'Rahman', '1995-03-15', '+18765909087', 'rita12@gmail.com', '20 berkeely West', 'Lethbridge', 'ALberta', 'T1K4B8', 'Dr. Govinder', 'Itching due to drug reaction', '2018-05-03'),
(8, 'Farhana', 'Rahman', '1995-03-15', '+18765909087', 'rita12@gmail.com', '980 berkeely West', 'Lethbridge', 'ALberta', 'T1K4B8', 'Dr. Govinder', 'Itching due to drug reaction', '2018-05-03'),
(9, 'Tahmina', 'Mustafa', '1990-09-07', '4876543298', 'mustafa@gmail.com', '345 Nw', 'Edmonton', 'ALBERTA', 'T5H1M5', 'Dr. Hasan', 'blood pressure raises', '2018-09-03'),
(10, 'etwrey', 'rewyery', '1998-09-04', '3456765432', 'retrey', 'ryreyer', 'LETHBRIDGE', 'ALBERTA', 'T1K4B8', 'Dr. Kader', 'safgf', '2019-08-02');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointments`
--
ALTER TABLE `appointments`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointments`
--
ALTER TABLE `appointments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
